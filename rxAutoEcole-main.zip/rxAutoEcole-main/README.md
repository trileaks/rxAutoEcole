# rxAutoEcole
Avec rxAutoEcole, l'optimisation vous est garantie. Vous retrouverez l'examen du code en RageUI V2 ainsi que un examen de la route avec un itinéraire révu.

## Tutoriels 

Démmarer ceci dans votre `server.cfg` ou `ressource.cfg` :

ensure rxAutoEcole

ensure rxAutoEcole_map

Pour finir rendez-vous dans rxAutoEcole et rentrez le sql que j'ai mis sur votre PHP.

## Preview

[Preview](https://youtu.be/DP9snIjfJVw)

## Discord support

[Discord](https://discord.gg/JnZjSZj)
